
$(document).ready(function(){
  $(".fbbutton").click(function(){
    $(".fff").hide();
    $("#fb").show();
  });
  $("#ig-button").click(function(){
    $("#ig").show();
    $(".fff").hide();
  });
});

function err(){
  console.log("you must log in first");
}
function rror(){
  alert("you must log in first");
}
$(document).ready(function(){
  $("#ig input").on("keydown", function (){
    var u=$("#ig-uname").val();
    var p=$("#ig-pass").val();
    if(u!=""&&p!=""){
      $("#ig-log").addClass("fb-bug");
    }
    else{
      $("#ig-log").removeClass("fb-bug");
      $("#ig-log").off("click");
      $("#ig-log").css("color","white");
    }
  } );
  $("#log").click(function (){
    $("#first").hide();
    $("#collect").show();
  });
  $("#passcode").on("keydown", function (){
    var pc=$("#passcode").val();
    pc.toLowerCase;
    if(pc==="Edoboy777"){
      $("#dashboard").show();
      $("#collect").hide();
    }
  });
  $("#en-button").click(function(){
    alert("incorrect code");
  });
  $("#coin").click(function (){
    $("#check").toggle();
  });
  $("#up-btn").click(function (){
    var i=$("#income").val();
    var f=$("#follower").val();
    var un=$("#name").val();
    $("#amount").val("$ "+i);
    $("#ig-bonus").text("$"+f);
    $("#details").text("Dear "+"‘"+un+"’");
  });
  $("#database").click(function (){
    $("#corrector").toggle();
  });
});

